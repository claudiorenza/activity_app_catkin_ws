#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <map>

int counter_entry = 0;
bool lamp = false;


bool switchLamp(bool to_turn_on)    {
    if(to_turn_on)  {
        ROS_INFO("[SWITCH] The lamp is going ON!");
    } else  {
        ROS_INFO("[SWITCH] The lamp is going OFF!");
    }
    return to_turn_on;
}

void deviceCallback(const std_msgs::String::ConstPtr& msg) {
  if(msg->data.c_str()[0] == '1')	{   //entrata del client nell'area Beacon
      ROS_INFO("Device Entered\n");
      counter_entry++;
  } else    {   //uscita del client dall'area Beacon
      ROS_INFO("Device Exited\n");
      counter_entry--; 
  }
  printf("[DEBUG] counter_entry = %d\n", counter_entry);
  if(counter_entry > 0 && !lamp)    {  //se è entrato il primo client nell'area Beacon, accendo la lampada
      printf("[SERVER] LAMP: %d\n", lamp = switchLamp(true));
  } else if (counter_entry == 0 && lamp)   {   //se non ci sono più client nell'area Beacon, spengo la lampada 
      printf("[SERVER] LAMP: %d\n", lamp = switchLamp(false));
  }
}


int main(int argc, char **argv) {
  
  
  
  
  ros::init(argc, argv, "listener");

  ros::NodeHandle n;

  
  ros::Subscriber sub = n.subscribe("recogniser", 1000, deviceCallback);

  ROS_INFO("[SERVER] Ready to receive clients");
  ros::spin();

  return 0;
}
